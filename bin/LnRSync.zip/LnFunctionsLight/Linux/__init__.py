#!/usr/bin/python
# -*- coding: iso-8859-1 -*-
#
# Scope:  ............
#                                               by Loreto Notarantonio
# ######################################################################################

from . wrLog                import wrLog
from . gv                import gv
from . gv                import gvc

MY_CONSTANT = 42
